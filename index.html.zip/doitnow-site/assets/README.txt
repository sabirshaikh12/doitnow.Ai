Drop images here (or in the repo root). Name them exactly as below; any of .webp .png .jpg .svg works.
No code changes needed. If a file is missing, the built-in graphic is used.

logo      icon-only mark in the header (the DOITNOW text stays)
robot     NEXORA AI assistant image in the hero
before    original document photo in the Document Studio slider
after     cleaned scan in the Document Studio slider
favicon   browser tab icon

Tip: after uploading, hard-refresh. GitHub Pages and browsers cache for a few minutes.
Keep images under ~300 KB (use .webp) for fast loading.
