// Site settings. GitHub Pages is static, so AI, accounts and payments need a separate backend.
// Never put secret keys in this repository: it is public.
window.DOITNOW={
  API_BASE:"",   // your backend address, e.g. "https://api.example.com". Leave empty until it is live.
  MAX_MB:10      // largest file a visitor may upload
};
