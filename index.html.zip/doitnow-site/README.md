# DOITNOW on GitHub Pages
1. Upload everything in this folder to a GitHub repository (root of the main branch).
2. Settings > Pages > Deploy from a branch > main, folder / (root).
3. Open https://USERNAME.github.io/REPO/ after about a minute.

Images: see assets/README.txt. Upload files with the right name and they appear automatically.
All links are relative, so the site works under /REPO/ and on a custom domain.

GitHub Pages is static hosting. AI tools, accounts, credits and payments need a separate backend
(for example Supabase Edge Functions or a Cloudflare Worker). Put its address in config.js as API_BASE.
The tool pages POST to API_BASE/api/<tool> and expect JSON like {"text": "..."} or {"downloadUrl": "..."}.
Never commit secret keys: the repository is public.
